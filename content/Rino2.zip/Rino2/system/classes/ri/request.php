<?php

//request, server, context, environment
class Ri_Request{
    protected $cliEnabled = true;
    
    public function __construct($resource = null, array $superglobals = array(), $method=null) {
        Ri::superglobals($params);
        if(!empty($method)) $_SERVER["REQUEST_METHOD"]=$method;
        $this->setCli(PHP_SAPI=="cli");
    }
    
    public function isHttps(){
        return strtolower($_SERVER["HTTPS"]) == "on";
    }
    public function setHttps($enabled){
        $_SERVER["HTTPS"]=$enabled ? "on" : "off";
        return $this;
    }
    
    public function isCli(){
        return $this->cliEnabled;
    }
    public function setCli($enabled){
        $this->cliEnabled = $enabled ? true : false;
        return $this;
    }
}