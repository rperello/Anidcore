<?php

define("RI_CHARS_HEXADECIMAL", "abcdef0123456789");
define("RI_CHARS_ALPHANUMERIC", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
define("RI_CHARS_SYMBOLS", "{}()[]<>!?|@#%&/=^*;,:.-_+");

class Ri {

    const VERSION = "0.3.0";

    /*
     * Superglobal context queue
     */

    protected static $contexts = array();
    protected static $contextIndex = -1;
    protected static $config = array();
    protected static $vars = array();
    protected static $finals = array();
    protected static $timers = array();
    protected static $requests = array();
    protected static $loaded_modules = array();

    public static function init() {
        if (empty(self::$contexts)) {
            self::contextBackup();
            self::$config = array_merge(array(
                "server.default_mimetype" => "text/html",
                "server.default_charset" => "UTF-8",
                "server.locale" => "en_US.UTF8",
                "server.timezone" => "UTC",
                "server.memory_limit" => "180M",
                "server.max_execution_time" => 60,
                "server.max_input_time" => -1,
                "server.post_max_size" => "24M",
                "server.upload_max_file_size" => "16M",
                "server.display_errors" => true,
                "server.error_reporting" => -1, //E_ALL & ~E_STRICT; // -1 | E_STRICT
                "server.error_log_file" => RI_PATH_LOGS . 'php_errors.log',
                "session.name" => "phpsessid_" . strtolower(str_replace("/", "", RI_BASEDIR)),
                "session.sessid_lifetime" => 180,
                "session.cookie_path" => '/' . RI_BASEDIR,
                "session.cookie_secure" => (isset($_SERVER["HTTPS"]) && ($_SERVER["HTTPS"] == "on")),
                "session.cookie_lifetime" => 0,
                "session.gc_maxlifetime" => 1440,
                "session.cache_expire" => 180,
                "session.cache_limiter" => "nocache",
                "log.enabled" => true,
                "log.class" => "Ri_Log",
                "key.names" => array("AUTH_SALT"), //extra generated keys
                "modules.config" => array(),
                "modules.autoload" => array(),
                "router.default_controller" => "index",
                    ), include RI_PATH_APP . "config.php");


            self::configureServer();
            self::generateKeys();
        }
    }

    public static function config($name = null, $default = false, $module = null) {
        if (empty($module)) {
            if (empty($name))
                return self::$config;

            if (isset(self::$config[$name])) {
                return self::$config[$name];
            }
        } else {
            if (!isset(self::$config["modules.config"][$module]))
                return $default;

            if (empty($name))
                return self::$config["modules.config"][$module];

            if (isset(self::$config["modules.config"][$module][$name])) {
                return self::$config["modules.config"][$module][$name];
            }
        }

        return $default;
    }

    public static function setConfig($name, $value, $module = null) {
        if (empty($module)) {
            if (!empty($name))
                self::$config[$name] = $value;
            else
                self::$config = $value;
        }else {
            if (!empty($name))
                self::$config["modules.config"][$module][$name] = $value;
            else
                self::$config["modules.config"][$module] = $value;
        }
    }

    /**
     * Gets / sets a registry variable
     * @param string $varname (if empty, returns all vars)
     * @param mixed $new_value (if not empty, sets the value of a var)
     * @return mixed 
     */
    public static function vars($varname = null) {
        if (empty($varname))
            return self::$vars;

        $args = func_get_args();
        if (count($args) == 2) {
            self::$vars[$varname] = $args[1];
            return null;
        } else {
            if (!isset(self::$vars[$varname]))
                return false;
            else
                return self::$vars[$varname];
        }
    }

    /**
     * Gets / sets a registry variable that can only be assigned once
     * (final vars, pseudo constants)
     * @param string $varname (if empty, returns all vars)
     * @param mixed $new_value (if not empty, assings a value to a non-existing var)
     * @return mixed 
     */
    public static function finals($varname = null) {
        if (empty($varname))
            return self::$finals;

        $args = func_get_args();
        if (count($args) == 2) {
            if (!isset(self::$finals[$varname]))
                self::$finals[$varname] = $args[1];
            return null;
        } else {
            if (!isset(self::$finals[$varname]))
                return false;
            else
                return self::$finals[$varname];
        }
    }

    public static function context() {
        return self::$contexts[self::$contextIndex];
    }

    public static function contextBackup() {
        $context = array(
            "_SERVER" => $_SERVER,
            "_GET" => $_GET,
            "_POST" => $_POST,
            "_FILES" => $_FILES,
            "_COOKIE" => $_COOKIE,
            "_REQUEST" => $_REQUEST,
            "_ENV" => $_ENV,
        );
        if (isset($_SESSION))
            $context["_SESSION"] = $_SESSION;

        if (isset($GLOBALS["argc"]))
            $context["argc"] = $GLOBALS["argc"];

        if (isset($GLOBALS["argv"]))
            $context["argv"] = $GLOBALS["argv"];

        self::$contexts[] = $context;
        self::$contextIndex++;
    }

    public static function contextRestore() {
        if (self::$contextIndex > 1) {
            array_pop(self::$contexts);
            self::$contextIndex--;
        }

        foreach (self::context() as $k => $arr) {
            $GLOBALS[$k] = $arr;
        }
    }

    public static function timerStart() {
        self::$timers[] = microtime(true);
    }

    public static function timerStop($start_time = null, $detailed_result = true) {
        if ($start_time == null) {
            if (!empty(self::$timers)) {
                $start_time = end(array_values(self::$timers));
                array_pop(self::$timers);
            }else
                return 0;
        }

        $end_time = round((microtime(true) - $start_time), 3);

        if ($detailed_result) {
            if ($end_time < 1) {
                $end_time_str = ($end_time * 1000) . "ms";
            }else
                $end_time_str = $end_time . "s";

            return $end_time_str;
        }else {
            return $end_time;
        }
    }

    protected static function generateKeys() {
        //Security Keys
        $keys_file = RI_PATH_DATA . "keys.data";
        if (!is_readable($keys_file)) {
            $security_keys = array(
                "key.GLOBAL_SALT" => ri_str_random(64, RI_CHARS_ALPHANUMERIC
                        . RI_CHARS_SYMBOLS)
            );
            foreach (self::$config["key.names"] as $i => $kn) {
                $security_keys["key." . $kn] = ri_str_random(64, RI_CHARS_ALPHANUMERIC
                        . RI_CHARS_SYMBOLS);
            }
            file_put_contents($keys_file, serialize($security_keys));
        } else {
            $security_keys = unserialize(file_get_contents($keys_file));
        }

        foreach ($security_keys as $k => $val) {
            self::$config[$k] = $val;
        }
    }

    /**
     *
     * @param array $config
     * @throws RuntimeException 
     */
    protected static function configureServer() {
        if (!is_dir(RI_PATH_LOGS))
            mkdir(RI_PATH_LOGS, 0770);
        if (!is_dir(RI_PATH_DATA))
            mkdir(RI_PATH_DATA, 0770);
        if (!is_dir(RI_PATH_CONTENT))
            mkdir(RI_PATH_CONTENT, 0775);

        //  Error reporting
        error_reporting(self::$config["server.error_reporting"]);
        ini_set("display_errors", self::$config["server.display_errors"] ? true : false); //stdout = output, stderr=error log file
        //  PHP environment variables
        if (!ini_get('safe_mode')) {

            set_time_limit(self::$config["server.max_execution_time"]);
            ini_set("memory_limit", self::$config["server.memory_limit"]);
            ini_set("max_execution_time", self::$config["server.max_execution_time"]);
            ini_set('upload_max_filesize', self::$config["server.upload_max_file_size"]);
            ini_set('post_max_size', self::$config["server.post_max_size"]);
            ini_set('max_input_time', self::$config["server.max_input_time"]);
            ini_set('default_charset', self::$config["server.default_charset"]);
            ini_set('default_mimetype', self::$config["server.default_mimetype"]);

            setlocale(LC_ALL, self::$config["server.locale"]);
            date_default_timezone_set(self::$config["server.timezone"]);

            ini_set("log_errors", true);
            ini_set('error_log', self::$config["server.error_log_file"]);

            ini_set("session.name", self::$config["session.name"]);
            ini_set("session.use_cookies", 1);
            ini_set("session.use_only_cookies", 1);
            ini_set("session.cookie_path", self::$config["session.cookie_path"]);
            ini_set("session.cookie_secure", self::$config["session.cookie_secure"]);
            ini_set("session.cookie_lifetime", self::$config["session.cookie_lifetime"]);
            ini_set('session.gc_maxlifetime', self::$config["session.gc_maxlifetime"]);
            ini_set("session.use_trans_sid", 0); # do not use PHPSESSID in urls
            ini_set("session.hash_function", 1); # use sha1 algorithm (160 bits)
            session_cache_expire(self::$config["session.cache_expire"]);
            session_cache_limiter(self::$config["session.cache_limiter"]);
        } else {
            self::exception("Rino Framework cannot be executed under safe_mode");
        }
    }

    public static function exception($message, $exitCode = -1) {
        throw new RuntimeException("Rino FATAL ERROR: " . $message);
        exit($exitCode);
    }

    public static function classFind($class_name, array $modules) {
        $class_file = null;
        $class_name_dir = str_replace("_", _DS, strtolower($class_name));

        /* /modules/<module>/classes/ folder */
        foreach ($modules as $name => $module) {
            /* @var $module Ri_Module */
            $class_file = $module->path . "classes" . _DS . $class_name_dir . ".php";
            $exists = self::classInclude($class_file, $class_name);
            if ($exists) {
                return $module;
            }
        }

        /* system/classes folder */
        $class_file = RI_PATH_SYSTEM . "classes" . _DS . $class_name_dir . ".php";
        if (self::classInclude($class_file, $class_name)) {
            return true;
        }

        return false;
    }

    /**
     * Includes the class file (once) and verifies that the class is loaded
     * @param string $class_file Full class file path
     * @param string $class_name Class name to verify
     * @return boolean 
     */
    public static function classInclude($class_file, $class_name) {
        if (is_readable($class_file)) {
            include_once $class_file;
            return class_exists($class_name, false);
        }
        return false;
    }

}