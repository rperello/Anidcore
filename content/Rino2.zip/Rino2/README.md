Rino
====

Rino is a PHP micro framework based on RESTFul and HMVC patterns.
It supports PHP 5.2.6+ and PHP in CLI mode.